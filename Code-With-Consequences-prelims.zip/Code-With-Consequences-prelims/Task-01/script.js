

// Define the team data
var images = ["/home/anudeep/code_with_consquence/WhatsApp Image 2023-05-04 at 00.13.34.jpeg", "image2.jpg", "image3.jpg", "image4.jpg"]; // array of image URLs
		var currentImageIndex = 0; // index of the current image being displayed

		// function to change the image to the previous one
		function showPrevImage() {
			currentImageIndex--;
			if (currentImageIndex < 0) {
				currentImageIndex = images.length - 1;
			}
			document.getElementById("image").src = images[currentImageIndex];
		}

		// function to change the image to the next one
		function showNextImage() {
			currentImageIndex++;
			if (currentImageIndex >= images.length) {
				currentImageIndex = 0;
			}
			document.getElementById("image").src = images[currentImageIndex];
		}

const team = [
  {
    name: "B.saiAnudeep",
    designation: "App Developer",
    description: "working under small projects like devloping applicaion for chat bot.",
    image: "/home/anudeep/code_with_consquence/WhatsApp Image 2023-05-04 at 00.13.34.jpeg"
  },
  {
    name: "A.Jayanth",
    designation: "Web Developer",
    description: "Created music website for clients which client can acess music all over world",
    image: "https://example.com/jane.png"
  },
  {
    name: "Kontham Pavan",
    designation: "AI proffesional",
    description: "Created a project for helping physical handicapped .",
    image: "https://example.com/bob.png"
  },

  {
    name: "M.V Charan",
    designation: "Data Scientist",
    description: "working in multinational company.",
    image: "https://example.com/bob.png"
  }
];

// Define the current team member index
let currentTeamMemberIndex = 0;

// Get the elements to update
const profileImage = document.querySelector('.profile-image img');
const name = document.querySelector('.name');
const designation = document.querySelector('.title');
const description = document.querySelector('.desc');

// Add event listeners to the buttons
const prevButton = document.querySelector('#prev-button');
const nextButton = document.querySelector('#next-button');

prevButton.addEventListener('click', () => {
  currentTeamMemberIndex--;
  if (currentTeamMemberIndex < 0) {
    currentTeamMemberIndex = team.length - 1;
  }
  updateTeamMember();
});

nextButton.addEventListener('click', () => {
  currentTeamMemberIndex++;
  if (currentTeamMemberIndex >= team.length) {
    currentTeamMemberIndex = 0;
  }
  updateTeamMember();
});

// Function to update the current team member
function updateTeamMember() {
  const currentTeamMember = team[currentTeamMemberIndex];
  profileImage.src = currentTeamMember.image;
  name.textContent = currentTeamMember.name;
  designation.textContent = currentTeamMember.designation;
  description.textContent = currentTeamMember.description;
}

// Call the function to initialize the profile with the first team member
updateTeamMember();
